################################################################################
#
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2017
# US Government Users Restricted Rights - Use, duplication disclosure restricted
# by GSA ADP Schedule Contract with IBM Corp.
#
################################################################################


from repository.mlrepository import MetaNames
from repository.mlrepository import MetaProps
from repository.mlrepository import ModelArtifact
from repository.mlrepositoryartifact.python_version import PythonVersion
from repository.mlrepositoryartifact.scikit_pipeline_reader import ScikitPipelineReader
from repository.mlrepositoryartifact.version_helper import ScikitVersionHelper
from sklearn.base import BaseEstimator


class ScikitPipelineModelArtifact(ModelArtifact):
    """
    Class of model artifacts created with MLRepositoryCLient.

    :param sklearn.pipeline.Pipeline scikit_pipeline_model: Pipeline Model which will be wrapped
    """
    def __init__(self, scikit_pipeline_model, uid=None, name=None, meta_props=MetaProps({})):
        super(ScikitPipelineModelArtifact, self).__init__(uid, name, meta_props)

        if not issubclass(type(scikit_pipeline_model), BaseEstimator):
            raise ValueError('Invalid type for scikit ml_pipeline_model: {}'.
                             format(scikit_pipeline_model.__class__.__name__))

        self.ml_pipeline_model = scikit_pipeline_model
        self.ml_pipeline = None     # no pipeline or parent reference

        self.meta.merge(
            MetaProps({
                MetaNames.MODEL_TYPE: ScikitVersionHelper.model_type(scikit_pipeline_model),
                # TODO: Uncomment below line once python-3.5 is added as a runtime
                #MetaNames.RUNTIME: 'python-{}'.format(PythonVersion.significant())
                MetaNames.RUNTIME: 'python-3.4'
            })
        )

    def pipeline_artifact(self):
        """
        Returns None. Pipeline is not implemented for scikit model.
        """
        pass

    def reader(self):
        """
        Returns reader used for getting pipeline model content.

        :return: reader for sklearn.pipeline.Pipeline
        :rtype: ScikitPipelineReader
        """
        try:
            return self._reader
        except:
            self._reader = ScikitPipelineReader(self.ml_pipeline_model)
            return self._reader

    def _copy(self, uid=None, meta_props=None):
        if uid is None:
            uid = self.uid

        if meta_props is None:
            meta_props = self.meta

        return ScikitPipelineModelArtifact(
            self.ml_pipeline_model,
            uid=uid,
            name=self.name,
            meta_props=meta_props
        )
