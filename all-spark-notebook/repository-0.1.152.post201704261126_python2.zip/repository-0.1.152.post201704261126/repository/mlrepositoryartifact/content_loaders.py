################################################################################
#
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2017
# US Government Users Restricted Rights - Use, duplication disclosure restricted
# by GSA ADP Schedule Contract with IBM Corp.
#
################################################################################

import os
from pyspark.ml import Pipeline, PipelineModel
from repository.mlrepositoryartifact.version_helper import ScikitModelBinary
from sklearn.externals import joblib


class SparkPipelineContentLoader(object):
    @staticmethod
    def load_content(content_dir):
        return Pipeline.read().load(content_dir)


class MLPipelineContentLoader(object):
    @staticmethod
    def load_content(content_dir):
        from mlpipelinepy import MLPipeline
        return MLPipeline.read().load(content_dir)


class IBMSparkPipelineContentLoader(object):
    @staticmethod
    def load_content(content_dir):
        from pipeline import IBMSparkPipeline
        return IBMSparkPipeline.read().load(content_dir)


class SparkPipelineModelContentLoader(object):
    @staticmethod
    def load_content(content_dir):
        return PipelineModel.read().load(content_dir)


class MLPipelineModelContentLoader(object):
    @staticmethod
    def load_content(content_dir):
        from mlpipelinepy import MLPipelineModel
        return MLPipelineModel.read().load(content_dir)


class IBMSparkPipelineModelContentLoader(object):
    @staticmethod
    def load_content(content_dir):
        from pipeline import IBMSparkPipelineModel
        return IBMSparkPipelineModel.read().load(content_dir)


class ScikitPipelineModelContentLoader(object):
    @staticmethod
    def load_content(content_dir):
        full_file_name = os.path.join(content_dir, ScikitModelBinary.bin_name())

        try:
            artifact_instance = joblib.load(full_file_name)
            return artifact_instance
        except Exception as ex:
            print ('Unable to load scikit model with sklearn.externals.joblib version ' + joblib.__version__)
            print ('Error message: ' + str(ex))
            raise ex

