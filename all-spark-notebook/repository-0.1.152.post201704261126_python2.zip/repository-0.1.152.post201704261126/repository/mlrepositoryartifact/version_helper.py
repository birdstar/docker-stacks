################################################################################
#
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2017
# US Government Users Restricted Rights - Use, duplication disclosure restricted
# by GSA ADP Schedule Contract with IBM Corp.
#
################################################################################


from .spark_version import SparkVersion
from sklearn.base import BaseEstimator


class VersionHelper(object):
    @staticmethod
    def significant():
        import pipeline
        version_parts = [int(version_part) for version_part in pipeline.__version__.split('.')]
        return "{}.{}".format(version_parts[0], version_parts[1])

    @staticmethod
    def pipeline_type(ml_pipeline):
        canonical_name = ml_pipeline.__class__.__name__
        if canonical_name == 'Pipeline':
            return 'sparkml-pipeline-{}'.format(SparkVersion.significant())
        elif canonical_name == 'IBMSparkPipeline':
            return 'ibm-sparkml-pipeline-{}'.format(VersionHelper.significant())
        elif canonical_name == 'MLPipeline':
            from mlpipelinepy import MLPipelineVersion
            return 'wml-sparkml-pipeline-{}.{}'.format(MLPipelineVersion.major_ver(), MLPipelineVersion.minor_ver())
        else:
            raise ValueError('Unsupported Pipeline class: {}'.format(canonical_name))

    @staticmethod
    def model_type(ml_pipeline_model):
        class_name = ml_pipeline_model.__class__.__name__
        if class_name == 'PipelineModel':
            return 'sparkml-model-{}'.format(SparkVersion.significant())
        elif class_name == 'IBMSparkPipelineModel':
            return 'ibm-sparkml-model-{}'.format(VersionHelper.significant())
        elif class_name == 'MLPipelineModel':
            from mlpipelinepy import MLPipelineVersion
            return 'wml-sparkml-model-{}.{}'.format(MLPipelineVersion.major_ver(), MLPipelineVersion.minor_ver())
        else:
            raise ValueError('Unsupported PipelineModel class: {}'.format(class_name))


class ScikitVersionHelper(object):
    @staticmethod
    def model_type(scikit_pipeline_model):
        class_name = scikit_pipeline_model.__class__.__name__
        if issubclass(type(scikit_pipeline_model), BaseEstimator):
            import sklearn
            return 'scikit-model-{}'.format(sklearn.__version__)
        else:
            raise ValueError('Unsupported ScikitPipelineModel class: {}'.format(class_name))


class ScikitModelBinary(object):
    @staticmethod
    def bin_name():
        return "scikit_pipeline.bin"
