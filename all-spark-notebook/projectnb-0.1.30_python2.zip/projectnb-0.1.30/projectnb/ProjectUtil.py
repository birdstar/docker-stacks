'''
Licensed Materials - Property of IBM

5737-D37

(C)Copyright IBM Corp. 2017 All Rights Reserved.

US Government Users Restricted Rights -Use, duplication or disclosure restricted by GSA ADPSchedule Contract with IBM Corp.

'''

'''
This module defines a set of functions that makes it easy to access CDS Project assets in a Spark notebook.
'''
import projectnb.ProjectUtilImpl


def list_available_files(pc):
    """
    Gets a list of files accessible by the current user from the project specified in the given 
    project context.
    """
    return projectnb.ProjectUtilImpl.listAvailableFiles(pc)

def list_available_files_data(pc):
    """
    Gets a list of file data structures for the files available to the current user from the project 
    specified in the given project context.
    """
    return projectnb.ProjectUtilImpl.listAvailableFilesData(pc)

def load_dataframe_from_file(pc, filenameOrFileData):
    """
    Creates and returns a DataFrame from the content of the given file reference in the project.  
    The given file reference can be a file name or a FileData object.  The file must be a CSV file.  
    """
    return projectnb.ProjectUtilImpl.loadDataFrameFromFile(pc, filenameOrFileData)

def load_dataframe_from_connector(pc, connectorName):
    """ 
    Creates and returns a DataFrame from a connector.
    """
    return projectnb.ProjectUtilImpl.loadDataFrameFromConnector(pc, connectorName)

def load_rdd_from_connector(pc, connectorName):
    """
    Creates and returns a RDD from a connector
    """
    return projectnb.ProjectUtilImpl.loadRDDFromConnector(pc, connectorName)

def load_rdd_from_file(pc, filename):
    """
    Creates and returns a RDD from the content of the named file in the project. 
    """
    return projectnb.ProjectUtilImpl.loadRDDFromFile(pc, filename)

# *****************Comment out Datalake for GA**************************************
# def store_dataframe_as_catalog_file(pc, df, filename):
#     """
#     Stores the content of the given RDD as a new project file with the given name in the Catalog service.
#     """
#     return projectnb.ProjectUtilImpl.storeSparkDataObjectAsDatalakeFile(pc, df, filename)

def store_dataframe_as_objectstore_file(pc, df, filename):
    """
    Stores the content of the given data frame as a new project file with the given name in the 
    Object Store service.
    """
    return projectnb.ProjectUtilImpl.storeSparkDataObjectAsObjectStoreFile(pc, df, filename)

def store_rdd_as_objectstore_file(pc, rdd, filename):
    """
    Stores the content of the given RDD as a new project file with the given name in the Object Store 
    service.
    """
    return projectnb.ProjectUtilImpl.storeSparkDataObjectAsObjectStoreFile(pc, rdd, filename)
