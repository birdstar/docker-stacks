'''
IBM Confidential

OCO Source Materials

5737-D37

(C)Copyright IBM Corp. 2017 All Rights Reserved.

The source code for this program is not published or otherwise divested of its trade secrets, irrespective of what has been deposited with the U.S. Copyright Office.

'''
import os
import sys

import json
from pyspark.rdd import RDD
from pyspark.sql import DataFrame
from pyspark.sql import SQLContext, SparkSession
import requests
requests.packages.urllib3.disable_warnings()

try:
    import pandas as pd
except ImportError:
    pass

try:
    import dsdbc
except ImportError:
    pass

try:
    import html
except ImportError:
    # Python 2.7
    import HTMLParser

import time
from Crypto.PublicKey import RSA
from base64 import b64decode

from projectnb.ProjectContext import ProjectContext
from projectnb.FileData import FileData

ProjectsServiceURL_prod = "https://api.apsportal.ibm.com/v2/projects"
ProjectsServiceURL_qa = "https://ngp-projects-api-qa.ng.bluemix.net/v2/projects"
ProjectsServiceURL_dev = "https://ngp-projects-api-dev.stage1.ng.bluemix.net/v2/projects"
ProjectsServiceURL_YS1_prod = "https://ngp-projects-api.stage1.ng.bluemix.net/v2/projects"
#ProjectsServiceURL_onPrem = "http://9.30.147.188:30044/v2/projects/"

DatalakeServiceURL_prod = "https://prod.data-lake.ibm.com/api/v1/data-lake"
DatalakeServiceURL_qa = "https://qa.data-lake.ibm.com/api/v1/data-lake"
DatalakeServiceURL_dev = "https://dev-lb.data-lake.ibm.com/api/v1/data-lake"
DatalakeServiceURL_YS1_prod = "https://stage-lb.data-lake.ibm.com/api/v1/data-lake"

InvalidEnvID = "invalid_environment_identifier"

S3Filetype = "S3 File"
DatalakeFiletype = "Datalake File"
ObjectStoreFiletype = "Object Store File"

S3FiletypeID = "file/s3"
DatalakeFiletypeID = "file/datalake-v1"
ObjectStoreFiletypeID = "file/bmos-v3"
ConnectionID = "connection/cdsx-v1"

PSEPAssets = "assets" # end point
PSParamName = "name"
PSParamType = "types"
PSParamValueS3File = S3FiletypeID
PSParamValueDatalakeFile = DatalakeFiletypeID
PSParamValueObjStoreFile = ObjectStoreFiletypeID
PSParamValueConnection = ConnectionID
PSParamValueDataSet = "dataset/exchange-v1"


AuthHeader = "Authorization"
DLEPComplete = "complete" # End Point
DLParamUseAWSToken = "use_aws_token"
AllFileTypes = [PSParamValueS3File, PSParamValueDatalakeFile, PSParamValueObjStoreFile]
connectorTypes = [PSParamValueConnection]
DatalakeFileTypes = [PSParamValueS3File, PSParamValueDatalakeFile]
ObjectStoreFileTypes = [PSParamValueObjStoreFile]
StorageType_ObjectStore = "object_storage"

AssetSupportedHDFSSources = ["hdfs-biginsights","hdfs-hortonworks", "hdfs-cloudera"]

AssetDatabaseTypeDB2 = "db2"
AssetDatabaseTypeDB2zOS = "db2zos"
AssetDatabaseTypeDashDB = "dashdb"
AssetDatabaseTypeMDSSzOS = "mfds"
AssetSupportedJDBCSources = [AssetDatabaseTypeDB2, "db2zos", "netezza", AssetDatabaseTypeDashDB, "oracle", "teradata","informix", AssetDatabaseTypeMDSSzOS]
AssetDB2sources = [AssetDatabaseTypeDB2, "db2zos", AssetDatabaseTypeDashDB]

AssetJdbcUrlSSLOptionsDB2 = ":sslConnection=true;"

IML_HOME = "IML_HOME"
tempDirPath = "/iml-library/output/tmp"
privateKey = "-----BEGIN RSA PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQCgcFRwabv1PC5iYUR+EO+jlg5ar3fJeU4piE18g1W2IH4NR14lkVVXCel6mh+hC5N0uSpi5OYPEIKSqKHRd/9G+yDoHPANeIBBfra244rBofVWrVff/1EMlFNnWj/rgpjPVaCgIQhRsIhOTw6rRF9PZCwtZGmi/vrzAqgDfANrFNDcYY97ofDm444Yi+A6rKzqB9kAzUVqcd4dkk4mGkChYodZavfXBowCIPkqX0MfjlT8UmFgc13K7FmN2PJI92YECIr+xHwkb6qKT2T7QqmrdrwdJuiUQ/qFHkoIN4h2D+KP5YXd6CbD4sKEwBBh8WOtgjDZNTVDFOGbIE6lTwl9AgMBAAECggEARBXnf50far8TYCSvEGDXkbCIfuugBhw4k1+IoqKJqTS4yaHTzlWSxdErCCCH86wZ85rw5e8Fwrba8qoloeMurky8dkRxiwXsR98iYxLFO88jcpk1hZWwK4p2qpGeNq/BcZuBAvOBuEkWT0U1kHD/kY2NQeYu/kD+9knWS0RBnxsWGor9P5u6TCaSKi3kjx63Z7l0rgic3fW0uH+1n8vQXttMVtO2D4uprwhQUjKLiiO6p9+BicNz+GNGCcCg5vEfV+04tnrBPRogE8NtHUfIg/RChp8ilvK6L7iaTyvpERjIMZcOGH38gYF3adCM6h5ZEJgqkVbZ98hNegyqtja7gQKBgQDVW/VmYF3Mf0mDvRjMsI+8GhuO7kbUZb/EBNaESqDUn1+3owVZ2wDFx15sOqTbdLPkbNml5F0B5/6H6hpI5xiB2WlCPZUsK+jUp/cEQGHIdpIS3rBAYBfn3nst3ofzRUGu6FC5Mbyip3kFzGxF4Gg6E2HIVyuvTNt3mNUdxX8w5QKBgQDAgNFEN8qo8/JF/xubWqkWA2yiqadeEePRukou90JW9bdzdlUA9bXwsYS87MGa/HynwVdJvYFDqUcnySovONYIpORGxOiMr6GzxdC62wNJ4mmNtsWC7JWohF7BhHXP6DgLIdzkrrWv7gpLePZ3rSLHAvAcIdqV/ZEtmtBIhaqkuQKBgCPPo4jjc9r3ImeyPY9ds0JnP2jmJY1Q5rcH+NmLjSMi/PXdrvA+CgsoQ3j2/uS22drlSkLF6baAMgCuEmtaHors6vXrUDZxyEqpRpS4GbGD9VClf//OITUR6qrwRvFWFog9Bg+PgZHreiy2+xVfbR8SUb9GolZyGAQi6uJsW8ThAoGANdLOsBg5Xcv3bYLKoUFUDYeflEuDNFYkMLu5ijAwKEhDptDrK32IBWhdCMXZzA/UesMgOMn3nodyEbm5RcLKdVhFS1Q7ATsKJ02j8trRrJLVmH4F83lazudT5x+2IQ94vAQX0wjWW/5eeoOzxfpuwt4bbII6r71aHjovClf1QmECgYAorq7lySBBzhgqrvcyuy8ypc42+WmSbH2ewruVsuRjFGHi6y9LxE00rKWUl0b2XKOguiqdGuE2ZxPajRxbyoxH0yum2y5+EKUGogzgrPccvIt19eMd6+Npqp6YJmEKKAjDp9RYF2w//WdNOW94/slwpd5xZX7dBazAMxifBmMpUw==\n-----END RSA PRIVATE KEY-----"

# "Front door" functions
def listAvailableFiles(pc):
    """
    Gets a list of files accessible by the current user from the project specified in
    the given project context.
    """
    filesDataResponse = getAvailableAssetsDataFromProjectsService(pc, AllFileTypes)
    filenameList = []
    if filesDataResponse.status_code == requests.codes['ok']:
        filenameList = getFilenameListFromAvailableFilesData(pc, filesDataResponse)
    else:
        logError(pc, "Unexpected response code {0} returned from available files call to projects service".format(filesDataResponse.status_code))
    return filenameList

def listAvailableFilesData(pc):
    """
    Gets a list of file data structures for the files available to the current user from the project
    specified in the given project context.
    """
    filesDataResponse = getAvailableAssetsDataFromProjectsService(pc, AllFileTypes)
    filesData = []
    if filesDataResponse.status_code == requests.codes['ok']:
        filesData = getFileDataListFromAvailableFilesData(pc, filesDataResponse)
    else:
        logError(pc, "Unexpected response code {0} returned from available files call to projects service".format(filesDataResponse.status_code))
    return filesData

def loadDataFrameFromFile(pc, filenameOrFileData):
    """
    Creates and returns a DataFrame from the content of the given file reference in the project.
    The given file reference can be a file name or a FileData object.  The file must be a CSV file.
    """
    filename = ""
    if type(filenameOrFileData) is str:
        filename = filenameOrFileData
    elif isinstance(filenameOrFileData, FileData):
        fileData = filenameOrFileData
        filename = fileData.filename
    else:
        logError(pc, "Second argument for loadDataFrameFromFile call must be a string or a FileData object.")

    filesDataResponse = getAvailableAssetsDataFromProjectsService(pc, AllFileTypes)
    df = None
    if filesDataResponse.status_code == requests.codes['ok']:
        log(pc, "RC OK from getAvailableAssetsDataFromProjectsService call")
        df = getDataFrameForNamedFile(pc, filesDataResponse, filename)
        display(pc, "Dataframe created")
    else:
        display(pc, "Unexpected response code {0} returned from available files call to Projects Service, please check if the service token of ProjectContext(pc) is invalid or the Projects Service is not available".format(filesDataResponse.status_code))
    return df

def loadDataFrameFromConnector(pc, connectorName):
    """
    Creates and returns a DataFrame from a connector.
    """
    filename = connectorName

    filesDataResponse = getAvailableAssetsDataFromProjectsService(pc, connectorTypes)
    df = None
    if filesDataResponse.status_code == requests.codes['ok']:
        log(pc, "RC OK from getAvailableAssetsDataFromProjectsService call")
        df = getDataFrameForNamedFile(pc, filesDataResponse, filename)
        display(pc, "Dataframe created")
    else:
        display(pc, "Unexpected response code {0} returned from available connectors call to Projects Service, please check if the service token of ProjectContext(pc) is invalid or the Projects Service is not available".format(filesDataResponse.status_code))
    return df


def loadRDDFromConnector(pc, connectorName):
    """
    Creates and returns a RDD from a connector.
    """
    filename = connectorName

    filesDataResponse = getAvailableAssetsDataFromProjectsService(pc, connectorTypes)
    rdd = None
    if filesDataResponse.status_code == requests.codes['ok']:
        log(pc, "RC OK from getAvailableAssetsDataFromProjectsService call")
        rdd = getRDDForNamedFile(pc, filesDataResponse, filename)
        log(pc, "RDD created")
    else:
        logError(pc, "Unexpected response code {0} returned from available connectors call to Projects Service".format(filesDataResponse.status_code))
    return rdd

def loadRDDFromFile(pc, filename):
    """
    Creates and returns a RDD from the content of the named file in the project.
    """
    rdd = None
    display(pc, "Creating RDD, this will take a few moments...")
    filesDataResponse = getAvailableAssetsDataFromProjectsService(pc, AllFileTypes)
    if filesDataResponse.status_code == requests.codes['ok']:
        log(pc, "RC OK from getAvailableAssetsDataFromProjectsService call")
        rdd = getRDDForNamedFile(pc, filesDataResponse, filename)
        log(pc, "RDD created")
    else:
        logError(pc, "Unexpected response code {0} returned from available files call to Projects Service".format(filesDataResponse.status_code))

    return rdd

def storeSparkDataObjectAsDatalakeFile(pc, sparkData, filename):
    """
    Stores the content of the given Spark data object as a new project file with the given name in the
    Datalake service.
    """
    result = False
    checkResult = checkIfFileExistsInDatalake(pc, filename)
    if checkResult is not None:
        if checkResult is True:
            logError(pc, "A file with name {0} already exists in the Catalog".format(filename))
        else:
            # continue to store the file
            storageTypeAndID = getStorageTypeAndIdForProject(pc)
            if storageTypeAndID is None:
                logError(pc, "Could not obtain storage ID for Catalog Service.")
            else:
                storageType, storageID = storageTypeAndID  #storageType is not used here
                addAssetResponse = requestToAddAssetToDatalake(pc, filename, storageID, pc.projectID)
                if addAssetResponse.status_code  == requests.codes['ok']:
                    log(pc, "Request to add asset to Datalake succeeded!")
                    addAssetJson = addAssetResponse.json()
                    assetID = addAssetJson['asset_id']
                    addAssetURL = addAssetJson['url']
                    newfile = createFileFromSparkDataObject(pc, sparkData, filename)
                    log(pc, "New file is at " + newfile.name)
                    writeAssetResponse = writeAssetToDatalake(pc, addAssetURL, newfile)
                    if writeAssetResponse.status_code == requests.codes['created'] or writeAssetResponse.status_code == requests.codes['ok']:
                        log(pc, "File write to storage service succeeded!")
                        addAssetCompleteResponse = notifyDatalakeServiceAddAssetComplete(pc, assetID, storageID)
                        if addAssetCompleteResponse.status_code == requests.codes['ok']:
                            log(pc, "Notify-complete call to Catalog Service succeeded!")
                            addFileAssetToProjectResult = addFileAssetToProject(pc, filename, assetID, storageID)
                            if addFileAssetToProjectResult == True:
                                log(pc, "Add file asset to project succeeded")
                            else:
                                log(pc, "Add file asset to project failed")
                            result = addFileAssetToProjectResult
                        else:
                            logError(pc, "Notify complete call to Catalog Service failed!")
                    else:
                        logError(pc, "File write to storage service failed, RC = " + str(writeAssetResponse.status_code))
                    os.remove(newfile.name)
                else:
                    logError(pc, "Request to add asset to Datalake failed!, result code = " + str(addAssetResponse.status_code))
    else:
        # Error message is handled in the checkIfFileExistsInDatalake function
        pass

    return result

def storeSparkDataObjectAsObjectStoreFile(pc, sparkData, filename):
    """
    Stores the content of the given Spark data object as a new project file with the given name in the
    Object Store service.
    """
    result = False
    # We need to get all available asset types because we need to check the filename against them
    # We don't want duplicate asset names in our common project
    availAssetsResponse = getAllAvailableAssetsDataFromProjectsService(pc)
    if availAssetsResponse.status_code == requests.codes['ok']:
        log(pc, "RC OK from getAvailableAssetsDataFromProjectsService call")
        assetDataList = getAssetDataList(pc, availAssetsResponse)
        filteredAssetDataList = [fileData for fileData in assetDataList if fileData['name'] == filename]
        if len(filteredAssetDataList) > 0:
            logError(pc, "A file with name {0} already exists in the Object Store".format(filename))
        else:
            # We need some extra meta-data to store the new asset in the project.  If there is
            # an existing object store file associated with the project, use the meta-data from that.
            #If not, create it here directly.
            assetData = None
            #Need OS json instead of connector json. filter out connector json
            filteredAssetDataList = [fileData for fileData in assetDataList if fileData['type'] == ObjectStoreFiletypeID]
            if len(filteredAssetDataList) > 0:
                assetData = filteredAssetDataList[0]
            else:
                assetData = {}
                assetData["name"] = filename
                properties = {}
                properties["id"] = filename
                properties["hash"] = ""
                properties["project_storage"] = True
                assetData["properties"] = properties

            storageInfo = getStorageInfoForObjectStore(pc, assetData)

            # Get the asset properties and massage them to contain the data that we
            # need to write the new file into the object store. (Apparently the hash
            # code isn't required, so remove it if present.)

            properties = assetData['properties']
            properties['id'] = filename
            properties['hash'] = ""

            storageInfoProperties = storageInfo['properties']
            credentials = storageInfoProperties['credentials']
            authURL = credentials['auth_url']
            if isOnPrem(pc) == False:
                authURL = authURL + '/v3/auth/tokens'
            userID = credentials['userId']
            username = credentials['username']
            password = credentials['password']
            projectID = credentials['projectId']
            region = None
            if isOnPrem(pc):
                region = "not-used"
            else:
                region = credentials['region']
            container = storageInfoProperties['container']

            authResponse = authenticateWithObjectStore(pc, authURL, userID, username, password, projectID)
            if authResponse.status_code == requests.codes['created'] or authResponse.status_code == requests.codes['ok']:
                authResponseHeaders = authResponse.headers
                authToken = None
                if isOnPrem(pc):
                    authResponseJson = authResponse.json()
                    access = authResponseJson['access']
                    token = access['token']
                    authToken = token['id']
                else:
                    authToken = authResponseHeaders['X-Subject-Token']
                log(pc, "Object Store auth token is " + authToken)
                authResponseJson = authResponse.json()
                objStoreURL = getObjectStoreURLFromAuthResponse(pc, authResponseJson, region, container, filename)
                log(pc, "Object Store URL is " + objStoreURL)
                newfile = createFileFromSparkDataObject(pc, sparkData, filename)
                filepath = os.path.realpath(newfile.name)
                log(pc, "New file is at " + filepath)
                writeAssetResponse = writeAssetToObjectStore(pc, objStoreURL, newfile, authToken)
                if writeAssetResponse.status_code == requests.codes['created'] or writeAssetResponse.status_code == requests.codes['ok']:
                    log(pc, "File write to Object Store succeeded!")
                    addFileAssetToProjectResult = addObjectStoreFileAssetToProject(pc, filename, properties)
                    result = addFileAssetToProjectResult
                    resultStr = "failed!"
                    if result:
                        resultStr = "succeeded!"
                    log(pc, "Add file asset to project " + resultStr)
                else:
                    logError(pc, "File write to storage service failed, RC = " + str(writeAssetResponse.status_code))
                #os.remove(newfile.name)
            else:
                log(pc, "Authorization could not be obtained for the Object Store, RC = " + str(authResponse.status_code))
    else:
        logError(pc, "Unexpected response code {0} returned from available files call to Projects Service".format(availAssetsResponse.status_code))

    return result

# "Work horse" functions

def getFilenameListFromAvailableFilesData(pc, filesData):
    """
    Gets a list of file names from the given available files data structure obtained from the projects
    service.  The files data structure must be in JSON format.
    """
    filenameList = []
    filesDataJson = filesData.json()
    assetList = filesDataJson["assets"]
    log(pc, "Asset count is " + str(len(assetList)))
    for asset in assetList:
        filename = asset["name"]
        filenameList.append(filename)
    return filenameList

def getFileDataListFromAvailableFilesData(pc, filesData):
    """
    Returns a list of file data objects from the given file data JSON string.
    """
    fileDataList = []
    filesDataJson = filesData.json()
    assetList = filesDataJson["assets"]
    log(pc, "Asset count is " + str(len(assetList)))
    for asset in assetList:
        filename = asset["name"]
        filetype = asset["type"]
        fileData = FileData(filename, mapToUIFileType(filetype))
        fileDataList.append(fileData)
    return fileDataList

def getDataFrameForNamedFile(pc, filesData, filename):
    """
    Gets a data frame for the named file using the given files data structure obtained from the Projects
    Service.  The files data structure must be in JSON format.
    """
    df = None
    assetData = getAssetDataForNamedFile(pc, filesData, filename)
    if assetData is not None:
        filetype = assetData["type"]
        if filetype == DatalakeFiletypeID:
            assetURL = assetData["url"]
            log(pc, "asset URL is " + assetURL)
            assetAccessData = getAssetAccessDataFromDatalakeService(pc, assetURL)
            if assetAccessData.status_code == requests.codes['ok']:
                log(pc, "RC OK from getAssetAccessDataFromDatalakeService call")
                df = getDataFrameForDatalakeAsset(pc, assetAccessData)
            else:
                logError(pc, "DataFrame could not be created due to failure to get asset access data from Datalake service")
        elif filetype == ObjectStoreFiletypeID:
            storageInfo = getStorageInfoForObjectStore(pc, assetData)
            if storageInfo:
                df = getDataFrameForObjectStoreAsset(pc, assetData, storageInfo)
        elif filetype == ConnectionID:
            databaseType = assetData["properties"]["parameters"]["database_type"]
            if databaseType in AssetSupportedHDFSSources:
                df = getDataFrameForHDFSFile(pc, assetData)
            elif databaseType in AssetSupportedJDBCSources:
                df = getDataFrameForDatabaseTable(pc,assetData)
            else:
                logError(pc,"Unsupportable database type: {0}".format(databaseType))
        else:
            logError(pc, "Unexpected file type {0} encountered in asset data".format(filetype))
    else:
        logError(pc, "DataFrame could not be created due to failure to get asset data for the source file")
    return df


def getDataFrameForDatabaseTable(pc, assetData):
    '''
        Create and get dataframe for database from data asset
    '''
    df = None
    filename = assetData["name"]
    parameters = assetData["properties"]["parameters"]
    password = parameters["password"]
    host = parameters["host"]
    port = parameters["port"]
    user = parameters["user"]
    dbType = parameters["database_type"]
    dbTableOrQuery = ""

#The logic is fairly simple. Check sql_query is available. If it's there then use sql input. If it's not, search table.
#Then check table input. If it's new version, then use table_name input. If it's old version, directly grab table and schema
#Check schema is given and deal with it
    if("sql_query_text" in parameters):
        dbtable = parameters["sql_query_text"]["sql_query"]
        if sys.version > '3':
            dbtable = html.unescape(dbtable)
        else:
            dbtable = HTMLParser.HTMLParser().unescape(dbtable)
        dbtable = dbtable.strip() #get rid of space at the end for removing semi later
        if(dbtable[-1]==';'):
            dbtable=dbtable[:-1]
        dbTableOrQuery = dbtable
        #Spark requires () for sql input
    else:
        if("table_name" in parameters):
            schema = parameters["table_name"]["schema"]
            table = parameters["table_name"]["table"]
        else:
            schema = parameters.get('schema')
            table = parameters["table"]
        #Check Schema empty or not
        if (schema is None or schema.strip() == ""):
            dbTableOrQuery = table
        elif len(schema)!=0:
            dbTableOrQuery = schema + "." + table
        if dbType == AssetDatabaseTypeMDSSzOS:
            dbTableOrQuery = table

    # Check if ossl has an invalid value.
    ossl = "off"
    if "ossl" in parameters:
        if parameters['ossl'] in ["on", "off"]:
            ossl = parameters['ossl']
        else:
            logError(pc, "Invalid value for ossl option in parameters field: " + parameters['ossl'] + ". Defaulting to value of off instead.")
    # If the ossl option is missing from parameters field it means it should be off.

    dbForURL = dbType
    if dbForURL in AssetDB2sources:
        dbForURL="db2"
    elif dbForURL == AssetDatabaseTypeMDSSzOS:
        dbForURL="rs:dv"

    database =""
    baseUrl = ""

    '''
        oracle thin jdbc urls are a little different:
        jdbc:oracle:thin:@803rthy.canlab.ibm.com:1521:orcl
        jdbc:oracle:thin:@<host>:<port>:<SID>
        jdbc:oracle:thin:@<host>:<port>/<SERVICE>

        Design choice of oracle connector was made to allow for either choice: SID or SERVICE (one or the other but not both)
    '''

    if dbType == "oracle":
        baseUrl="jdbc:oracle:thin:@" + host + ":"+port

        if("service" in parameters and len(parameters["service"]) > 0 ):
            baseUrl+="/" + parameters["service"]
        elif("sid" in parameters and len(parameters["sid"]) > 0):
            baseUrl+=":" + parameters["sid"]
        else:
            raise ValueError('Neither SID or SERVICE were provided in the JSON for the oracle Connector!')
    elif dbType == "teradata":
        database = parameters["database"]
        baseUrl = "jdbc:" + dbForURL + "://" + host + "/DATABASE=" + database + ",DBS_PORT=" + port
    elif dbType == "informix":
        database = parameters["database"]
        server = parameters["server"]
        baseUrl = "jdbc:informix-sqli://" + host + ":" + port + "/" + database + ":INFORMIXSERVER=" + server + ";DELIMIDENT=y"
        #For further information about delimident settings, please check https://github.ibm.com/PrivateCloud/spark/wiki/Informix-connection-with-Spark
    elif dbType == AssetDatabaseTypeMDSSzOS:
        baseUrl == "jdbc:" + dbForURL + "://" + host + ":" + port
    else:
        database = parameters["location"]
        baseUrl = "jdbc:" + dbForURL + "://" + host + ":" + port + "/" + database
    url = amendJdbcUrlWithSSLOptions(pc, dbType, ossl, baseUrl)
    log(pc, "jdbc url is " + url)

    if dbType == AssetDatabaseTypeMDSSzOS:
        mdss_conn = dsdbc.connect(SSID=parameters.get('ssid'),USER=user,PASSWORD=decodeRSA(password))
        mdss_sql = "SELECT * FROM " + dbTableOrQuery
        df = pd.read_sql(mdss_sql, mdss_conn)
    elif dbType == AssetDatabaseTypeDB2zOS:
        sparkContext = pc.sc
        sparkSession = SparkSession(sparkContext).builder.getOrCreate()
        df = sparkSession.read.format("jdbc").option("url", url).option("driver","com.ibm.db2.jcc.DB2Driver").option("dbtable",dbTableOrQuery).option("user",user).option("password",decodeRSA(password)).load()
    else:
        sparkContext = pc.sc
        sparkSession = SparkSession(sparkContext).builder.getOrCreate()
        df = sparkSession.read.format("jdbc").option("url", url).option("dbtable",dbTableOrQuery).option("user",user).option("password",decodeRSA(password)).load()

    return df


def getRDDForNamedFile(pc, filesData, filename):
    """
    Gets an RDD for the named file using the given files data structure obtained from the Projects
    Service.  The files data structure must be in JSON format. A special error RDD is returned if the RDD can't
    be constructed.
    """
    rdd = None
    assetData = getAssetDataForNamedFile(pc, filesData, filename)
    if assetData is not None:
        filetype = assetData["type"]
        if filetype == DatalakeFiletypeID:
            assetURL = assetData["url"]
            log(pc, "asset URL is " + assetURL)
            assetAccessData = getAssetAccessDataFromDatalakeService(pc, assetURL)
            if assetAccessData.status_code == requests.codes['ok']:
                log(pc, "RC OK from getAssetAccessDataFromDatalakeService call")
                rdd = getRDDForDatalakeAsset(pc, assetAccessData)
            else:
                logError(pc, "DataFrame could not be created due to failure to get asset access data from Datalake service")
        elif filetype == ObjectStoreFiletypeID:
            storageInfo = getStorageInfoForObjectStore(pc, assetData)
            if storageInfo:
                rdd = getRDDForObjectStoreAsset(pc, assetData, storageInfo)
        elif filetype ==ConnectionID:
            databaseType = assetData["properties"]["parameters"]["database_type"]
            if databaseType in AssetSupportedHDFSSources:
                rdd = getRDDForHDFSFile(pc, assetData)
            else:
                logError(pc,"Unsupportable database type: {0}".format(databaseType))
        else:
            logError(pc, "Unexpected file type {0} encountered in asset data".format(filetype))
    else:
        logError(pc, "RDD could not be created due to failure to get asset data for the source file")

    return rdd

def getAssetDataList(pc, filesData):
    """
    Parses the given files data structure and returns a list of JSON values representing the asset
    data for each file in the structure.
    """
    log(pc, "Getting asset data list")
    filesDataJson = filesData.json()
    assetDataList = filesDataJson['assets']

    return assetDataList

def getAssetDataForNamedFile(pc, filesData, fileName):
    """
    Gets a JSON structure containing the asset data for the file with the given name.
    """
    log(pc, "Getting asset data for file named " + fileName)
    filesDataJson = filesData.json()
    assetList = filesDataJson["assets"]
    filteredList = [asset for asset in assetList if asset["name"] == fileName]
    if len(filteredList) == 1:
        log(pc, "Asset data found " )
        return filteredList[0]
    else:
        log(pc, "No asset data or multiple asset data entries found for file named " + fileName)
        return None

def getDataFrameForDatalakeAsset(pc, assetAccessData):
    """
    Gets a data frame for the Datalake asset represented by the given asset data.
    """
    assetAccessDataJson = assetAccessData.json()
    assetId = assetAccessDataJson["asset_id"]
    assetURL = assetAccessDataJson["url"]
    log(pc, "Asset URL is " + assetURL)
    filepath = pc.home + os.path.sep + "data" + os.path.sep + assetId + ".CSV"
    df = None
    loadFileResponse = loadFileFromDatalake(pc, assetURL, filepath)
    if loadFileResponse.status_code == requests.codes['ok']:
        df = getDataFrameFromFile(pc, filepath)
        log(pc, "Deleting temp file: " + filepath)
        os.remove(filepath)
    else:
        log(pc, "File data could not be loaded from Catalog for asset ID " + assetId)
    return df

def getRDDForDatalakeAsset(pc, assetAccessData):
    """
    Gets an RDD for the Datalake asset represented by the given asset data.
    """
    assetAccessDataJson = assetAccessData.json()
    assetId = assetAccessDataJson["asset_id"]
    assetURL = assetAccessDataJson["url"]
    log(pc, "Asset URL is " + assetURL)
    filepath = pc.home + os.path.sep + "data" + os.path.sep + assetId + ".CSV"
    rdd = None
    loadFileResponse = loadFileFromDatalake(pc, assetURL, filepath)
    if loadFileResponse.status_code == requests.codes['ok']:
        rdd = getRDDFromFile(pc, filepath)
        log(pc, "Deleting temp file: " + filepath)
        os.remove(filepath)
    else:
        log(pc, "File data could not be loaded from Catalog for asset ID " + assetId)

    return rdd

def getDataFrameFromFile(pc, filepath):
    """
    Gets a data frame from the file with the given file path.
    """
    sparkContext = pc.sc
    sparkSession = SparkSession(sparkContext).builder.getOrCreate()
    log(pc, "filepath is " + filepath)
    df = sparkSession.read.csv(filepath, header = 'true', inferSchema = 'true')
    log(pc, "Spark df is " + str(df))
    return df

def getRDDFromFile(pc, filepath):
    """
    Gets an RDD from the file with the given file path.
    """
    rdd = None
    log(pc, "About to call Spark to create a RDD")
    log(pc, "filepath is " + filepath)

    rdd = pc.sc.textFile(filepath)
    return rdd

def checkIfFileExistsInDatalake(pc, filename):
    """
    Checks if a file with the given name already exists in the Catalog (Datalake) associated with
    this project and returns true if the file already exists, false if it doesn't, and None if an
    error is encountered.
    """
    availFilesResponse = getAvailableAssetsDataFromProjectsService(pc, DatalakeFileTypes)
    checkResult = False
    if availFilesResponse.status_code == requests.codes['ok']:
        log(pc, "RC OK from getAvailableAssetsDataFromProjectsService call")
        filesDataJson = availFilesResponse.json()
        assetList = filesDataJson["assets"]
        filteredAssetList = [asset for asset in assetList if asset["name"] == filename]
        checkResult = len(filteredAssetList) > 0
    else:
        "Unexpected response code {0} returned when storing file".format(availFilesResponse.status_code)
        checkResult = None
    return checkResult

def getDataFrameForObjectStoreAsset(pc, assetData, storageInfo):
    """
    Gets a data frame for the ObjectStore asset represented by the given asset data.
    """
    filename = assetData['name']
    properties = storageInfo['properties']
    credentials = properties['credentials']
    projectID = credentials['projectId']
    region = None
    if isOnPrem(pc):
        region = "not-used"
    else:
        region = credentials['region']
    userID = credentials['userId']
    username = credentials['username']
    password = credentials['password']
    authURL = credentials['auth_url']
    if isOnPrem(pc) == False:
        authURL = authURL + '/v3/auth/tokens'
    container = properties['container']

    df = None
    authResponse = authenticateWithObjectStore(pc, authURL, userID, username, password, projectID)
    if authResponse.status_code == requests.codes['created'] or authResponse.status_code == requests.codes['ok']:
        authResponseHeaders = authResponse.headers
        authToken = None
        if isOnPrem(pc):
            authResponseJson = authResponse.json()
            access = authResponseJson['access']
            token = access['token']
            authToken = token['id']
        else:
            authToken = authResponseHeaders['X-Subject-Token']
        log(pc, "Object Store auth token is " + authToken)
        authResponseJson = authResponse.json()
        objStoreURL = getObjectStoreURLFromAuthResponse(pc, authResponseJson, region, container, filename)
        log(pc, "Object Store URL is " + objStoreURL)

        filepath = getTempDirPath(pc) + os.path.sep + getcurrentTimeMillis() + "_" + filename
        loadResponse = loadFileFromObjectStore(pc, objStoreURL, filepath, authToken)
        if loadResponse.status_code == requests.codes['ok']:
            df = getDataFrameFromFile(pc, filepath)
        else:
            log(pc, "File data could not be loaded from the Object Store for " + filename + ", RC = " + str(loadResponse.status_code))
    else:
        log(pc, "Authorization could not be obtained for the Object Store, RC = " + str(authResponse.status_code))

    return df

def getDataFrameForHDFSFile(pc, assetData):
    """
    Gets a data frame for the HDFS File represented by the given asset data.
    """
    df = None
    sparkContext = pc.sc
    sparkSession = SparkSession(sparkContext).builder.getOrCreate()
    properties = assetData['properties']
    parameters = properties['parameters']
    protocol = parameters['protocol']
    host = parameters['host']
    port = parameters['port']
    url = protocol + "://" + host + ":" + port
    file = parameters['file']
    file_format = parameters['file_format']
    file_fullpath = url + file
    log(pc, "filepath is " + file_fullpath)

    #To check if the file_csv_options is missing or just an empty string. We are expecting a dictionary here.
    if "file_csv_options" in parameters and isinstance(parameters['file_csv_options'],dict):
        header_option = parameters['file_csv_options']['header']
        inferSchema_option = parameters['file_csv_options']['inferSchema']
    else :
        header_option = "on"
        inferSchema_option = "on"

    header_option = header_option.lower()
    inferSchema_option = inferSchema_option.lower()

    if(header_option == "on"):
        header_option = "true"
    elif(header_option=="off"):
        header_option = "false"
    if(inferSchema_option=="on"):
        inferSchema_option = "true"
    elif(inferSchema_option=="off"):
        inferSchema_option = "false"

    #To check if the input is valid.
    options = ["true","false"]
    if(header_option not in options):
        log(pc,"Invalid value for header option in file_csv_option field: " + header_option + ". Defaulting to value of true instead.")
        header_option = "true"
    if(inferSchema_option not in options):
        log(pc,"Invalid value for inferSchema option in file_csv_option field: " + inferSchema_option + ". Defaulting to value of true instead.")
        inferSchema_option = "true"

    if file_format == 'csv':
       df = sparkSession.read.csv(file_fullpath, header = header_option, inferSchema = inferSchema_option)
    else:
       log(pc, "file_format is not supported for getDataFrameForHDFSFile()")

    return df

def getRDDForHDFSFile(pc, assetData):
    """
    Gets a RDD for the HDFS File represented by the given asset data.
    """
    rdd = None
    properties = assetData['properties']
    parameters = properties['parameters']
    protocol = parameters['protocol']
    host = parameters['host']
    port = parameters['port']
    url = protocol + "://" + host + ":" + port
    file = parameters['file']
    file_format = parameters['file_format']
    file_fullpath = url + file
    log(pc, "filepath is " + file_fullpath)

    if file_format == 'text':
        rdd = pc.sc.textFile(file_fullpath)
    else:
        log(pc, "file_format is not supported for getRDDForHDFSFile()")
    return rdd

def getRDDForObjectStoreAsset(pc, assetData, storageInfo):
    """
    Gets an RDD for the ObjectStore asset represented by the given asset data.
    """
    filename = assetData['name']
    properties = storageInfo['properties']
    credentials = properties['credentials']
    projectID = credentials['projectId']
    region = credentials['region']
    userID = credentials['userId']
    username = credentials['username']
    password = credentials['password']
    authURL = credentials['auth_url']
    if isOnPrem(pc) == False:
        authURL = authURL + '/v3/auth/tokens'
    container = properties['container']

    rdd = None
    authResponse = authenticateWithObjectStore(pc, authURL, userID, username, password, projectID)
    if authResponse.status_code == requests.codes['created'] or authResponse.status_code == requests.codes['ok']:
        authResponseHeaders = authResponse.headers
        authToken = None
        if isOnPrem(pc):
            authResponseJson = authResponse.json()
            access = authResponseJson['access']
            token = access['token']
            authToken = token['id']
        else:
            authToken = authResponseHeaders['X-Subject-Token']
        log(pc, "Object Store auth token is " + authToken)
        authResponseJson = authResponse.json()
        objStoreURL = getObjectStoreURLFromAuthResponse(pc, authResponseJson, region, container, filename)
        log(pc, "Object Store URL is " + objStoreURL)

        filepath = os.path.join(pc.home, 'data', filename)
        loadResponse = loadFileFromObjectStore(pc, objStoreURL, filepath, authToken)
        if loadResponse.status_code == requests.codes['ok']:
            rdd = getRDDFromFile(pc, filepath)
        else:
            log(pc, "File data could not be loaded from the Object Store for " + filename + ", RC = " + str(loadResponse.status_code))
    else:
        log(pc, "Authorization could not be obtained for the Object Store, RC = " + str(authResponse.status_code))

    return rdd

def getObjectStoreURLFromAuthResponse(pc, authResponseJson, requiredRegion, container, filename):
    """
    Derives and returns a URL for accessing the Object Store from the given authorization response JSON
    structure, region, container, and file name.
    """
    objStoreURL = "Object Store URL not found"
    urlBase = None

    if isOnPrem(pc):
        #urlBase = 'http://9.30.166.132:8089/v1/AUTH_2d9ae30d26ff4c8b91a784fb40ce7c2c'
        objectStorageURL = "PRIVATE_CLOUD_OBJECT_STORAGE_URL_var_not_defined"
        access = authResponseJson['access']
        token = access['token']
        tenant = token['tenant']
        tenantIDStr = tenant['id']
        urlBase = "https://" + pc.repositoryIp + "/swiftstorage/v1" + "/AUTH_" + tenantIDStr
    else:
        tokenJson = authResponseJson['token']
        catalogListJson = tokenJson['catalog']
        foundCatalog = None
        for catalogJson in catalogListJson:
            typeStr = catalogJson['type']
            if typeStr == 'object-store':
                foundCatalog = catalogJson
                break

        if foundCatalog:
            endpointsListJson = foundCatalog['endpoints']
            for endpointJson in endpointsListJson:
                regionStr = endpointJson['region']
                urlStr = endpointJson['url']
                interfaceStr = endpointJson['interface']
                if regionStr == requiredRegion and interfaceStr == 'public':
                    urlBase = urlStr
                    break

    if urlBase:
        objStoreURL = urlBase + "/" + container.replace(" ", "%20") + "/" + filename.replace(" ", "%20")

    return objStoreURL

def getStorageTypeAndIdForProject(pc):
    """
    Gets the storage type and ID (guid) associated with the project contained in the given project
    context. The result is a tuple of strings, (<storageType>, <storageId>).  If the values can't be
    determined, the result is a tuple containing values ("storageTypeNotFound", "storageIdNotFound").
    """
    storageTypeAndId = None
    projectDataResponse = getProjectDataFromProjectsService(pc)
    if projectDataResponse.status_code == requests.codes['ok']:
        log(pc, "RC OK from getProjectDataFromProjectsService call")
        projectDataJson = projectDataResponse.json()
        entityJson = projectDataJson["entity"]
        storageJson = entityJson["storage"]
        storageType = storageJson["type"]
        storageID = storageJson["guid"]
        storageTypeAndId = (storageType, storageID)
    return storageTypeAndId

def createFileFromSparkDataObject(pc, sparkDataObj, filename):
    """
    Creates and returns a file with the given name from the given Spark data object
    (that is, an RDD or DataFrame).
    """
    dirPath = os.path.join(pc.home, 'data', filename)
    filePath = dirPath + ".CSV"
    log(pc, "Temp directory for Spark repartition-write is " + dirPath)
    if isinstance(sparkDataObj, DataFrame):
        sparkDataObj.repartition(1).write.format("com.databricks.spark.csv") \
            .option("header", "true").option("delimiter", ",").save(dirPath)
    elif isinstance(sparkDataObj, RDD):
        sparkDataObj.repartition(1).saveAsTextFile(dirPath)

    tmpPartFilename = ""
    log(pc, "Files create by Spark repartition-write are the following:")
    tmpFilenameList = os.listdir(dirPath)
    for tmpFilename in tmpFilenameList:
        log(pc, tmpFilename)
        if tmpFilename == "part-00000" or tmpFilename.endswith(".csv"):
            tmpPartFilename = tmpFilename

    tmpPartFilePath = os.path.join(dirPath, tmpPartFilename)
    log(pc, "Renaming " + tmpPartFilePath + " to " + filePath)
    os.rename(tmpPartFilePath, filePath)
    newfile = open(filePath, 'r')

    # Clean up the directory where the DF wrote the "partition".
    log(pc, "Cleaning up by deleting all files in " + dirPath)
    filelist = os.listdir(dirPath)
    for afile in filelist:
        os.remove(os.path.join(dirPath, afile))
    os.rmdir(dirPath)

    return newfile

def getStorageInfoForObjectStore(pc, assetData):
    """
    Gets storage info from Projects service for the Object Store associated with the project.
    Note: if the project is an "Object Store" project, the storage info is defined once for the
    entire project.  If the project is a "Catalog" (Data lake) project, then the storage info is
    contained in the given asset (file) data object.
    """
    storageInfo = None
    projectDataResponse = getProjectDataFromProjectsService(pc)
    if projectDataResponse.status_code == requests.codes['ok']:
        log(pc, "RC OK from getProjectDataFromProjectsService call")
        projectDataJson = projectDataResponse.json()
        entityJson = projectDataJson["entity"]
        storageJson = entityJson["storage"]
        storageType = storageJson["type"]
        storageInfo = assetData
        if storageType == StorageType_ObjectStore:
            storageInfo = storageJson
    else:
        logError(pc, "Unexpected response code {0} returned from get project data from Projects Service call".format(projectDataResponse.status_code))

    return storageInfo

def addFileAssetToProject(pc, filename, assetID, datalakeID):
    """
    Adds a file asset with the given asset ID and asset URL to the current project.
    """
    addFileAssetToProjectResult = False
    postAssetResponse = postAssetToProjectsService(pc, filename, assetID, datalakeID)
    if postAssetResponse.status_code == requests.codes['ok']:
        log(pc, "Post asset to project service was successful!")
        addFileAssetToProjectResult = True
    else:
        log(pc, "Posting asset to project service failed, RC is " + str(postAssetResponse.status_code))

    return addFileAssetToProjectResult

def addObjectStoreFileAssetToProject(pc, filename, properties):
    """
    Adds an Object Store file to the current project.
    """
    addFileAssetToProjectResult = False
    postAssetResponse = postObjectStoreAssetToProjectsService(pc, filename, properties)
    if postAssetResponse.status_code == requests.codes['ok']:
        log(pc, "Post asset to project service was successful!")
        addFileAssetToProjectResult = True
    else:
        log(pc, "Posting asset to project service failed, RC is " + str(postAssetResponse.status_code))

    return addFileAssetToProjectResult

# HTTP (REST) functions

def getProjectDataFromProjectsService(pc):
    """
    Gets data for a given project from the Projects Service.  The result is an HTTP response.
    """
    if isOnPrem(pc):
        baseUrl = "https://" + pc.repositoryIp + "/v2/projects"
        serviceURL = composeServiceURL(baseUrl, pc.projectID, "", "", [])
        accessToken = "Bearer " + pc.serviceToken
        headers = {AuthHeader: accessToken}
        log(pc, "getProjectDataFromProjectsService URL is " + serviceURL)
        r = requests.get(serviceURL, headers=headers, verify=False, allow_redirects=False)
    else:
        serviceURL = composeServiceURL(getProjectsServiceURL(pc), pc.projectID, "", "", [])
        headers = {AuthHeader: pc.accessToken}
        log(pc, "getProjectDataFromProjectsService URL is " + serviceURL)
        r = requests.get(serviceURL, headers=headers)
    return r

def getAvailableAssetsDataFromProjectsService(pc, typeList):
    """
    Gets data for files available to the current user from the Projects Service.  The result is
    an object representing the complete HTTP response.
    """
    baseUrl = "https://" + pc.repositoryIp + "/v2/projects"
    serviceURL = composeServiceURL(baseUrl, pc.projectID, PSEPAssets, "", {PSParamType: typeList})
    accessToken = "Bearer " + pc.serviceToken
    headers = {AuthHeader: accessToken}
    log(pc, "getAvailableAssetsFromProjectsService URL is " + serviceURL)
    r = requests.get(serviceURL, headers=headers, verify=False, allow_redirects=False)
    log(pc, "getAvailableAssetsFromProjectsService URL is " + serviceURL)
    return r

def getAllAvailableAssetsDataFromProjectsService(pc):
    """
    Gets data for all files available to the current user from the Projects Service.  The result is
    an object representing the complete HTTP response.
    """
    # Passing an empty list as parameter to the service URL, so it takes in all asset types.
    # If that list had any elements, it would filter by those elements and wouldn't take all assets
    serviceURL = composeServiceURL(getProjectsServiceURL(pc), pc.projectID, PSEPAssets, "", list())
    headers = {AuthHeader: pc.accessToken}
    log(pc, "getAllAvailableAssetsFromProjectsService URL is " + serviceURL)
    r = requests.get(serviceURL, headers=headers)
    return r

def getAssetAccessDataFromDatalakeService(pc, assetURL):
    """
    Gets asset access data from the Datalake Service for the asset identified by the given URL.
    """
    serviceURL = composeServiceURL(assetURL, "", "", "", {DLParamUseAWSToken: ["false"]})
    headers = {AuthHeader: pc.accessToken}
    log(pc, "getAssetDataFromDatalakeService URL is " + serviceURL)
    r = requests.get(serviceURL, headers=headers)
    return r

def loadFileFromDatalake(pc, datalakeAssetURL, filepath):
    """
    Loads a local file with the given file path from the Datalake file store represented by the given URL.
    """
    log(pc, "loadFileFromDatalake datalake asset URL is " + datalakeAssetURL)
    log(pc, "filepath is " + filepath)
    r = requests.get(datalakeAssetURL, stream=True)
    with open(filepath, 'wt') as f:
        for line in r.iter_lines():
            f.write(str(line) + '\n')
    log(pc, "file size is " + str(os.stat(filepath).st_size) + " bytes" )
    return r

def requestToAddAssetToDatalake(pc, fileName, datalakeID, projectID):
    """
    Initiates a request to the Catalog (Datalake) Service to add a file asset to the Catalog.
    The result is an HTTP response.
    """
    requestURL = composeServiceURL(getDatalakeServiceURL(pc), datalakeID, "", "", list())
    log(pc, "requestToAddAssetToDatalake URL is " + requestURL)
    data = {}
    data["name"] = fileName
    data["data_format"] = "application/csv"
    data["file_format"] = "application/csv"
    data["origin_country"] = "US"
    data["use_aws_token"] = "false"
    data["sandbox_guid"] = projectID
    log(pc, "Request to add asset data is " + str(data))
    headers = {AuthHeader: pc.accessToken, 'Content-Type': 'application/json', 'Accept': 'application/json' }
    r = requests.post(requestURL, json = data, headers = headers)
    return r

def writeAssetToDatalake(pc, assetURL, aFile):
    """
    Writes the content of the given file to the project storage provider using the given URL.
    """
    log(pc, "Writing content of " + aFile.name + " to storage as " + assetURL)
#     r = requests.post(assetURL, files={'file': open(file.name, 'rb')})
    with open(aFile.name, 'rb') as fh:
        fileline = fh.read()
        r = requests.put(assetURL, data = fileline)

    return r

def writeAssetToObjectStore(pc, assetURL, aFile, authToken):
    """
    Writes the given file content to the Object storage provider using the given URL.
    """
    log(pc, "Writing file content to Object Store")
    headers = {'MIME-Type': 'application/csv', 'X-Auth-Token': authToken}
    with open(aFile.name, 'rb') as fh:
        fileline = fh.read()
        r = requests.put(assetURL, data = fileline, headers=headers)

    return r

def notifyDatalakeServiceAddAssetComplete(pc, assetID, datalakeID):
    """
    Notifies the Catalog Service that the process of writing the asset to storage is completed.
    """
    serviceURL = composeServiceURL(getDatalakeServiceURL(pc), datalakeID, "asset/" + assetID, DLEPComplete, list())
    log(pc, "notifyDatalakeServiceAddAssetComplete URL is " + serviceURL)
    data = ""
    headers = {AuthHeader: pc.accessToken, 'Content-Type': 'application/json', 'Accept': 'application/json' }
    r = requests.post(serviceURL, json = data, headers = headers)
    log(pc, "Notify Catalog service that write of asset completed response code is " + str(r.status_code))
    return r

def authenticateWithObjectStore(pc, authURL, userID, username, password, projectID):
    """
    Authenticates with an Object Store using the given auth URL, user ID, username, password, and project ID.
    """
    log(pc, "authenticate object store, URL = " + authURL + ", user ID = " + userID + ", project ID = " + projectID)
    authDict = None
    if isOnPrem(pc):
        authDict = {
            'auth': {
                'tenantName': 'swift-tenant',
                'passwordCredentials': {
                    'username': username,
                    'password': password
                }
            }
        }
    else:
        authDict = {
            'auth':  {
                'identity': {
                    'methods': ['password'],
                    'password': {
                        'user': {
                            'id': userID,
                            'password': password
                         }
                    }
                },
                'scope': {
                    'project': {
                        'id': projectID
                    }
                }
            }
        }

    json_input = json.dumps(authDict)
    headers = {'Content-Type': 'application/json'}
    if isOnPrem(pc):
        authURL = "https://" + pc.repositoryIp + "/swiftauth"
        r = requests.post(authURL, data=json_input, headers=headers, verify=False)
    else:
        r = requests.post(authURL, data=json_input, headers=headers)
    return r

def loadFileFromObjectStore(pc, objStoreURL, filepath, authToken):
    """
    Loads a local file with the given file path from the file stored in the Swift Object Store represented
    by the given URL.
    """
    log(pc, "loadFileFromObjectStore object store URL is " + objStoreURL)
    log(pc, "filepath is " + filepath)
    headers = {"X-Auth-Token": authToken}
    r = requests.get(objStoreURL, stream=True, headers=headers, verify=False)
    with open(filepath, 'w') as f:
        for line in r.iter_lines():
            f.write(str(line) + '\n')
    log(pc, "file size is " + str(os.stat(filepath).st_size) + " bytes" )
    return r

def postAssetToProjectsService(pc, filename, assetID, datalakeID):
    """
    Posts an asset with the given asset ID and URL to the Projects service.  The result is an
    HTTP response.
    """
    serviceURL = composeServiceURL(getProjectsServiceURL(pc), pc.projectID, PSEPAssets, "", list() )
    log(pc, "postAssetToProjectsService URL is " + serviceURL)
    datalakeURL = getDatalakeServiceURL(pc) + "/" + datalakeID + "/asset/" + assetID
    json_input = '{"assets": [{"type": "' + DatalakeFiletypeID + '", "name": "' + filename + '", "url": "' + datalakeURL + \
    '", "properties": {"asset_id": "' + assetID + '", "data_format": "application/csv", "file_format": "application/csv", "sandbox": true}}]}'

    log(pc, "Asset data for postAssetToProjectsService is " + json_input)
    headers = {AuthHeader: pc.accessToken, 'Content-Type': 'application/json'}
    r = requests.post(serviceURL, data = json_input, headers = headers)
    return r

def postObjectStoreAssetToProjectsService(pc, filename, properties):
    """
    Posts an Object Store asset with the given guid and URL to the Projects service.  The result is an array of strings
    representing an HTTP response.
    """
    serviceURL = composeServiceURL(getProjectsServiceURL(pc), pc.projectID, PSEPAssets, "", list() )
    log(pc, "postAssetToProjectsService URL is " + serviceURL)
    propertiesStr = json.dumps(properties)
    json_input = '{"assets": [{"type": "' + ObjectStoreFiletypeID + '", "name": "' + filename + \
    '", "mime_type": "text/csv", "url": "#", "properties": ' + propertiesStr + '}]}'

    log(pc, "Asset data for postAssetToProjectsService is " + json_input)
    headers = {AuthHeader: pc.accessToken, 'Content-Type': 'application/json'}
    r = requests.post(serviceURL, data = json_input, headers = headers)
    return r

# Misc. utility functions

def getProjectsServiceURL(pc):
    """
    Gets the Projects service URL to use based on the environment field of the given project context.
    """
    env = pc.environment
    url = InvalidEnvID
    if env == ProjectContext.ENV_ID_prod:
        url = ProjectsServiceURL_prod
    elif env == ProjectContext.ENV_ID_qa:
        url = ProjectsServiceURL_qa
    elif env == ProjectContext.ENV_ID_dev:
        url = ProjectsServiceURL_dev
    elif env == ProjectContext.ENV_ID_YS1_prod:
        url = ProjectsServiceURL_YS1_prod
    elif env == ProjectContext.ENV_ID_onPrem:
        projectServiceURL = "PRIVATE_CLOUD_PROJECT_SERVICE_URL_var_not_defined"
        try:
            projectServiceURL = os.environ["PRIVATE_CLOUD_PROJECT_SERVICE_URL"]
        except KeyError:
            print("Environment variable PRIVATE_CLOUD_PROJECT_SERVICE_URL is not set.")
        url = projectServiceURL

    return url

def getDatalakeServiceURL(pc):
    """
    Gets the Datalake service URL to use, based on the environment field of the given project context.
    """
    env = pc.environment
    url = InvalidEnvID
    if env == ProjectContext.ENV_ID_prod:
        url = DatalakeServiceURL_prod
    elif env == ProjectContext.ENV_ID_qa:
        url = DatalakeServiceURL_qa
    elif env == ProjectContext.ENV_ID_dev:
        url = DatalakeServiceURL_dev
    elif env == ProjectContext.ENV_ID_YS1_prod:
        url = DatalakeServiceURL_YS1_prod

    return url

def composeServiceURL(baseURL, objId1, endPoint, objId2, paramList):
    """
    Builds and returns a service URL composed of the given base URL, object ids, end-point, and param list.
    """
    urlObjId1 = "/" + objId1 if len(objId1) > 0 else ""
    urlEP = "/" + endPoint if len(endPoint) > 0 else ""
    urlObjId2 = "/" + objId2 if len(objId2) > 0 else ""
    urlParamList = ""
    if len(paramList) > 0:
        urlParamList = "?"
        paramListKeys = list(paramList)
        for key in paramListKeys:
            urlParamList = urlParamList + key + "="
            valueList = paramList[key]
            urlParamList = urlParamList + ",".join(valueList)

    return baseURL + urlObjId1 + urlEP + urlObjId2 + urlParamList

def amendJdbcUrlWithSSLOptions(pc, dbType, ossl, baseUrl):
    """
    Given the database type and SSL value in the asset JSON
    amend the JDBC URL accordingly.
    """
    url = baseUrl

    if ossl == "on":
        if dbType == AssetDatabaseTypeDB2 or dbType == AssetDatabaseTypeDashDB:
            url = baseUrl + AssetJdbcUrlSSLOptionsDB2
        # amend JDBC URL for other relational data sources here.
        else:
            logError(pc, "Unsupported database type for SSL. JDBC URL not amended.")
    return url

def mapToUIFileType(filetype):
    uiFiletype = filetype
    if filetype == S3FiletypeID:
        uiFiletype = S3Filetype
    elif filetype == DatalakeFiletypeID :
        uiFiletype = DatalakeFiletype
    elif filetype == ObjectStoreFiletypeID:
        uiFiletype = ObjectStoreFiletype

    return uiFiletype

def pkcs1_unpad(text):
    if len(text) > 0 and text.index(b'\x02') == 0:
        # Find end of padding marked by nul
        pos = text.find(b'\x00')
        if pos > 0:
            return text[pos+1:].decode('utf-8')
    return None

def decodeRSA(text):
    rsa_key = RSA.importKey(privateKey)
    raw_cipher_data = b64decode(text)
    phn = rsa_key.decrypt(raw_cipher_data)
    unpad_phn = pkcs1_unpad(phn)
    return unpad_phn

def getIMLHome(pc):
    imlHome = os.environ.get(IML_HOME)
    if (imlHome is None or imlHome.strip() == ""):
        display(pc, "IML_HOME is not set")
    return imlHome

def getTempDirPath(pc):
    path = getIMLHome(pc) + tempDirPath
    return path

def getcurrentTimeMillis():
    millis = int(round(time.time() * 1000))
    return str(millis)

def isOnPrem(pc):
    return pc.environment == ProjectContext.ENV_ID_onPrem

def display(pc, msg):
    print(msg)

def logError(pc, msg):
    print(msg)

def log(pc, msg):
    if pc.debug == True:
        print(msg)
