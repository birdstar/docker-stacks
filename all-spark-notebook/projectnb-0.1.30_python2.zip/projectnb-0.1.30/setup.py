from setuptools import setup

setup(name='projectnb',
      version='0.1.30',
      description='Utility for integrating DataWorks Projects with Spark Notebooks',
      #install_requires=['maven-artifact','mpld3'],
      license='Apache 2.0',
      packages=['projectnb'],
      include_package_data=True,
      zip_safe=False)
