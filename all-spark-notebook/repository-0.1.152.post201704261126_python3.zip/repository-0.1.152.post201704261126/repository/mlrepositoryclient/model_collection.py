################################################################################
#
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2017
# US Government Users Restricted Rights - Use, duplication disclosure restricted
# by GSA ADP Schedule Contract with IBM Corp.
#
################################################################################


import logging, re

from .model_adapter import ModelAdapter
from repository.swagger_client.rest import ApiException
from repository.mlrepository import MetaNames, ModelArtifact
from repository.swagger_client.models import ModelInput, ModelVersionInput, ModelTrainingDataRef, ModelVersionOutput,\
    MetaObjectMetadata, ModelVersionOutputEntity, ModelVersionOutputEntityModel, ArtifactAuthor, EvaluationDefinition, \
    EvaluationDefinitionMetrics, artifactMetaOptions, ArtifactOrigin, MetaOptions
from repository.util.json_2_object_mapper import Json2ObjectMapper

logger = logging.getLogger('ModelCollection')


class ModelCollection:
    """
    Client operating on models in repository service.

    :param str base_path: base url to Watson Machine Learning instance
    :param MLRepositoryApi repository_api: client connecting to repository rest api
    :param MLRepositoryClient client: high level client used for simplification and argument for constructors
    """
    def __init__(self, base_path, repository_api, client):

        from repository.mlrepositoryclient import MLRepositoryClient, MLRepositoryApi

        if not isinstance(base_path, str) and not isinstance(base_path, unicode):
            raise ValueError('Invalid type for base_path: {}'.format(base_path.__class__.__name__))

        if not isinstance(repository_api, MLRepositoryApi):
            raise ValueError('Invalid type for repository_api: {}'.format(repository_api.__class__.__name__))

        if not isinstance(client, MLRepositoryClient):
            raise ValueError('Invalid type for client: {}'.format(client.__class__.__name__))

        self.base_path = base_path
        self.repository_api = repository_api
        self.client = client

    def all(self):
        """
        Gets info about all models which belong to this user.

        Not complete information is provided by all(). To get detailed information about model use get().

        :return: info about models
        :rtype: list[ModelArtifact]
        """
        logger.debug('Fetching information about all models')
        all_models = self.repository_api.get_pipeline_models()
        if all_models is not None:
            return map(lambda model_data: self._extract_model_from_output(model_data), all_models.resources)
        else:
            return []

    def get(self, artifact_id):
        """
        Gets detailed information about model.

        :param str artifact_id: uid used to identify model
        :return: returned object has all attributes of SparkPipelineModelArtifact but its class name is ModelArtifact
        :rtype: ModelArtifact(SparkPipelineModelLoader)
        """
        logger.debug('Fetching information about pipeline model: {}'.format(artifact_id))

        if not isinstance(artifact_id, str):
            raise ValueError('Invalid type for artifact_id: {}'.format(artifact_id.__class__.__name__))

        model_output = self.repository_api.get_pipeline_model(artifact_id)

        if model_output is not None:
            latest_version = model_output.entity.latest_version

            if latest_version is not None:
                logger.debug(' -> latest version: {}'.format(latest_version.guid))
                latest_version_output = self.repository_api.get_pipeline_model_version(artifact_id, latest_version.guid)
            else:
                latest_version_output = None

            return ModelAdapter(model_output, latest_version_output, self.client).artifact()

        else:
            logger.debug('Model with guid={} not found'.format(artifact_id))
            raise ApiException('Model with guid={} not found'.format(artifact_id))

    def versions(self, artifact_id):
        """
        Gets all available versions.

        Not implemented yet.

        :param str artifact_id: uid used to identify model
        :return: ???
        :rtype: list[str]
        """

        if not isinstance(artifact_id, str):
            raise ValueError('Invalid type for artifact_id: {}'.format(artifact_id.__class__.__name__))

        raise RuntimeError('Not implemented')

    def version(self, artifact_id, ver):
        """
        Gets model version with given artifact_id and ver
        :param str artifact_id: uid used to identify model
        :param str ver: uid used to identify version of model
        :return: ModelArtifact(SparkPipelineModelLoader) -- returned object has all attributes of SparkPipelineModelArtifact but its class name is ModelArtifact
        """
        logger.debug('Fetching information about model version: {}, {}'.format(artifact_id, ver))

        if not isinstance(artifact_id, str):
            raise ValueError('Invalid type for artifact_id: {}'.format(artifact_id.__class__.__name__))

        if not isinstance(ver, str):
            raise ValueError('Invalid type for ver: {}'.format(ver.__class__.__name__))

        model_version_output = self.repository_api.get_pipeline_model_version(artifact_id, ver)
        if model_version_output is not None:
            model_id = model_version_output.entity.model.guid
            model_output = self.repository_api.get_pipeline_model(model_id)
            if model_output is not None:
                return ModelAdapter(model_output, model_version_output, self.client).artifact()
            else:
                raise Exception('Model with guid={} not found'.format(model_id))
        else:
            raise Exception('Model with guid={} not found'.format(artifact_id))

    def version_from_href(self, artifact_version_href):
        """
        Gets model version from given href

        :param str artifact_version_href: href identifying artifact and version
        :return: returned object has all attributes of SparkPipelineModelArtifact but its class name is PipelineModelArtifact
        :rtype: PipelineModelArtifact(SparkPipelineModelLoader)
        """

        if not isinstance(artifact_version_href, str):
            raise ValueError('Invalid type for artifact_version_href: {}'.format(artifact_version_href.__class__.__name__))

        if artifact_version_href.startswith(self.base_path):
            matched = re.search('.*/v2/artifacts/models/([A-Za-z0-9\-]+)/versions/([A-Za-z0-9\-]+)',
                            artifact_version_href)
            if matched is not None:
                artifact_id = matched.group(1)
                version_id = matched.group(2)
                return self.version(artifact_id, version_id)
            else:
                raise ValueError('Unexpected artifact version href: {} format'.format(artifact_version_href))
        else:
            raise ValueError('The artifact version href: {} is not within the client host: {}'.format(
                artifact_version_href,
                self.base_path
            ))

    def remove(self, artifact_id):
        """
        Removes model with given artifact_id.

        :param str artifact_id: uid used to identify model
        """

        if not isinstance(artifact_id, str):
            raise ValueError('Invalid type for artifact_id: {}'.format(artifact_id.__class__.__name__))

        return self.repository_api.delete_pipeline_model(artifact_id)

    def save(self, artifact):
        if artifact.meta.prop(MetaNames.MODEL_TYPE).startswith("scikit-model-"):
            return self._save_scikit_pipeline_model(artifact)
        else:
            return self._save_spark_pipeline_model(artifact)

    def _save_scikit_pipeline_model(self, artifact):
        """
        Saves model in repository service.

        :param ScikitPipelineModelArtifact artifact: artifact to be saved in the repository service
        :return: saved artifact with changed MetaProps
        :rtype: ScikitPipelineModelArtifact
        """
        logger.debug('Creating a new scikit pipeline model: {}'.format(artifact.name))

        if not issubclass(type(artifact), ModelArtifact):
            raise ValueError('Invalid type for artifact: {}'.format(artifact.__class__.__name__))

        if artifact.meta.prop(MetaNames.MODEL_VERSION_HREF) is not None:
            raise ApiException(400, 'Invalid operation: save the same model artifact twice')

        try:
            if artifact.uid is None:
                model_artifact = self._create_pipeline_model(artifact)
            else:
                model_artifact = artifact

            if model_artifact.uid is None:
                raise RuntimeError('Internal Error: Model without ID')
            else:
                return self._create_pipeline_model_version(model_artifact)

        except Exception as e:
            logger.error('Error in pipeline model creation')
            raise e

    def _save_spark_pipeline_model(self, artifact):
        """
        Saves model in repository service.

        :param SparkPipelineModelArtifact artifact: artifact to be saved in the repository service
        :return: saved artifact with changed MetaProps
        :rtype: SparkPipelineModelArtifact
        """
        logger.debug('Creating a new pipeline model: {}'.format(artifact.name))

        if not issubclass(type(artifact), ModelArtifact):
            raise ValueError('Invalid type for artifact: {}'.format(artifact.__class__.__name__))

        if artifact.meta.prop(MetaNames.MODEL_VERSION_HREF) is not None:
            raise ApiException(400, 'Invalid operation: save the same model artifact twice')

        try:
            if artifact.uid is None:
                pipeline_artifact = artifact.pipeline_artifact()
                if pipeline_artifact.uid is None:
                    new_pipeline_artifact = self._create_pipeline(pipeline_artifact)
                    tmp_model_artifact = artifact._copy(pipeline_artifact=new_pipeline_artifact)

                    model_artifact = self._create_pipeline_model(tmp_model_artifact)
                else:
                    model_artifact = self._create_pipeline_model(artifact)
            else:
                model_artifact = artifact

            if model_artifact.uid is None:
                raise RuntimeError('Internal Error: Model without ID')
            else:
                return self._create_pipeline_model_version(model_artifact)

        except Exception as e:
            logger.error('Error in pipeline model creation')
            raise e

    def _create_pipeline(self, pipeline_artifact):
        return self.client.pipelines.save(pipeline_artifact)

    def _create_pipeline_model(self, model_artifact):
        model_input = self._get_model_input(model_artifact)
        r = self.repository_api.create_pipeline_model_with_http_info(model_input)
        location = r[2].get('Location')
        if location is not None:
            logger.debug('New pipeline model created at: {}'.format(location))
            matched = re.search('.*/v2/artifacts/models/([A-Za-z0-9\-]+)', location)
            model_id = matched.group(1)
            return model_artifact._copy(uid=model_id)
        else:
            logger.error('Location of the new pipeline model not found')
            raise ApiException(404, 'No artifact location')

    def _create_pipeline_model_version(self, model_artifact):
        model_version_input = self._get_version_input(model_artifact)
        r = self.repository_api.create_pipeline_model_version_with_http_info(model_artifact.uid, model_version_input)
        location = r[2].get('Location')
        if location is not None:
            logger.debug('New model version created at: {}'.format(location))
            try:
                new_version_artifact = self.version_from_href(location)
                new_version_artifact.model_instance = lambda: model_artifact.ml_pipeline_model
                model_artifact_with_version = model_artifact._copy(meta_props=new_version_artifact.meta)
                self._upload_pipeline_model_content(model_artifact_with_version)
                return new_version_artifact
            except Exception as ex:
                raise ex
        else:
            logger.error('Location of the new model version not found')
            raise ApiException(404, 'No artifact location')

    def _upload_pipeline_model_content(self, model_artifact):
        model_id = model_artifact.uid
        version_id = model_artifact.meta.prop(MetaNames.VERSION)

        if version_id is None:
            raise RuntimeError('Model meta `{}` not set'.format(MetaNames.VERSION))

        content_stream = model_artifact.reader().read()
        self.repository_api.upload_pipeline_model_version(model_id, version_id, content_stream)
        content_stream.close()
        model_artifact.reader().close()
        logger.debug('Content uploaded for model version created at: {}, {}'.format(model_id, version_id))

    def _extract_model_from_output(self, model_output):
        latest_version = model_output.entity.latest_version
        if latest_version is not None:
            latest_version_output = ModelVersionOutput(
                MetaObjectMetadata(
                    latest_version.guid,
                    latest_version.href, None, None
                ),
                ModelVersionOutputEntity(
                    ModelVersionOutputEntityModel(model_output.metadata.guid, model_output.metadata.href),
                    latest_version.content_href, None, None
                )
            )
        else:
            latest_version_output = None
        return ModelAdapter(model_output, latest_version_output, self.client).artifact()

    @staticmethod
    def _get_model_input(artifact):
        meta = artifact.meta
        # scikit-models does not implement pipelineVersionHref yet.
        if artifact.meta.prop(MetaNames.MODEL_TYPE).startswith("scikit-model-"):
            return ModelInput(
                artifact.name,
                meta.prop(MetaNames.DESCRIPTION),
                ArtifactAuthor(
                    meta.prop(MetaNames.AUTHOR_NAME),
                    meta.prop(MetaNames.AUTHOR_EMAIL)
                ),
                None,
                meta.prop(MetaNames.MODEL_TYPE),
                meta.prop(MetaNames.RUNTIME),
                None,
                None,
                None,
                artifactMetaOptions(
                    meta.prop(MetaNames.MODEL_META_PROJECT_ID),
                    meta.prop(MetaNames.MODEL_META_MODEL_DATA),
                    MetaOptions(
                        ArtifactOrigin(
                            meta.prop(MetaNames.MODEL_META_ORIGIN_TYPE),
                            meta.prop(MetaNames.MODEL_META_ORIGIN_ID)
                    )
                )
            )
            )
        else:
            pipeline_artifact = artifact.pipeline_artifact()
            return ModelInput(
                artifact.name,
                meta.prop(MetaNames.DESCRIPTION),
                ArtifactAuthor(
                    meta.prop(MetaNames.AUTHOR_NAME),
                    meta.prop(MetaNames.AUTHOR_EMAIL)
                ),
                pipeline_artifact.meta.prop(MetaNames.PIPELINE_VERSION_HREF),
                meta.prop(MetaNames.MODEL_TYPE),
                meta.prop(MetaNames.RUNTIME),
                meta.prop(MetaNames.TRAINING_DATA_SCHEMA),
                meta.prop(MetaNames.LABEL_FIELD),
                meta.prop(MetaNames.INPUT_DATA_SCHEMA)
            )

    @staticmethod
    def _get_version_input(artifact):
        meta = artifact.meta
        if artifact.meta.prop(MetaNames.MODEL_TYPE).startswith("scikit-model-"):
            return ModelVersionInput()
        else:
            training_data_ref = Json2ObjectMapper.read(meta.prop(MetaNames.TRAINING_DATA_REF))
            #if not training_data_ref: #check if is empty dict
            #    training_data_ref = None

            metrics = Json2ObjectMapper.read(meta.prop(MetaNames.EVALUATION_METRICS))
            metrics = map(
                lambda metrics_set: EvaluationDefinitionMetrics(metrics_set["name"], metrics_set["threshold"]),
                metrics
            )

            return ModelVersionInput(training_data_ref, EvaluationDefinition(
                meta.prop(MetaNames.EVALUATION_METHOD),
                metrics
            ))

