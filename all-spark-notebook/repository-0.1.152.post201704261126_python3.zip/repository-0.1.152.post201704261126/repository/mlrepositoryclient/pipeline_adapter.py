################################################################################
#
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2017
# US Government Users Restricted Rights - Use, duplication disclosure restricted
# by GSA ADP Schedule Contract with IBM Corp.
#
################################################################################


import re
from repository.mlrepository import MetaNames, MetaProps, PipelineArtifact
from repository.mlrepositoryartifact import SparkPipelineLoader, SparkPipelineContentLoader,\
    IBMSparkPipelineContentLoader, MLPipelineContentLoader
from repository.util import Json2ObjectMapper


class PipelineAdapter(object):
    """
    Adapter creating pipeline artifact using output from service.
    """
    def __init__(self, pipeline_output, version_output, client):
        self.pipeline_output = pipeline_output
        self.version_output = version_output
        self.client = client
        self.pipeline_type = pipeline_output.entity.type

    def artifact(self):
        if re.match('sparkml-pipeline-\d+\.\d+', self.pipeline_type) is not None:
            pipeline_artifact_builder = type(
                "PipelineArtifact",
                (SparkPipelineContentLoader, SparkPipelineLoader, PipelineArtifact, object),
                {}
            )
        elif re.match('ibm-sparkml-pipeline-\d+\.\d+', self.pipeline_type) is not None:
            pipeline_artifact_builder = type(
                "IBMPipelineArtifact",
                (IBMSparkPipelineContentLoader, SparkPipelineLoader, PipelineArtifact, object),
                {}
            )
        elif re.match('wml-sparkml-pipeline-\d+\.\d+', self.pipeline_type) is not None:
            pipeline_artifact_builder = type(
                "WMLPipelineArtifact",
                (MLPipelineContentLoader, SparkPipelineLoader, PipelineArtifact, object),
                {}
            )
        else:
            raise ValueError('Invalid pipeline_type: {}'.format(self.pipeline_type))

        prop_map = {
            MetaNames.CREATION_TIME: self.pipeline_output.metadata.created_at,
            MetaNames.LAST_UPDATED: self.pipeline_output.metadata.modified_at,
            MetaNames.PIPELINE_TYPE: self.pipeline_output.entity.type,
            MetaNames.RUNTIME: self.pipeline_output.entity.runtime_environment,
        }

        if self.pipeline_output.entity.description is not None:
            prop_map[MetaNames.DESCRIPTION] = self.pipeline_output.entity.description

        if self.pipeline_output.entity.author is not None:
            prop_map[MetaNames.AUTHOR_NAME] = self.pipeline_output.entity.author.name
            prop_map[MetaNames.AUTHOR_EMAIL] = self.pipeline_output.entity.author.email

        pipeline_artifact = pipeline_artifact_builder(
            self.pipeline_output.metadata.guid,
            self.pipeline_output.entity.name,
            MetaProps(prop_map))

        pipeline_artifact.client = self.client

        if self.version_output is not None:
            version_prop_map = {
                MetaNames.VERSION: self.version_output.metadata.guid,
                MetaNames.PIPELINE_VERSION_HREF: self.version_output.metadata.href
            }

            pipeline_artifact.meta.merge(MetaProps(version_prop_map))

            pipeline_artifact._content_href = self.version_output.entity.content_href

        else:
            pipeline_artifact._content_href = None

        return pipeline_artifact
