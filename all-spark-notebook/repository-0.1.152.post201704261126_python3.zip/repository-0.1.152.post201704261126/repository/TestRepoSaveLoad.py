# from sklearn.datasets import fetch_20newsgroups
from sklearn.datasets import fetch_20newsgroups
from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from shutil import rmtree
import logging
import numpy as np
import nose.tools as nt
import inspect
import os
import pprint

# WML Repo python client
from repository.mlrepository import MetaNames
from repository.mlrepository import MetaProps
from repository.mlrepositoryclient import MLRepositoryClient
from repository.mlrepositoryartifact import MLRepositoryArtifact


categories = ['alt.atheism', 'soc.religion.christian',
              'comp.graphics', 'sci.med']
twenty_train = fetch_20newsgroups(subset='train',
                                  categories=categories, shuffle=True, random_state=42)
twenty_test = fetch_20newsgroups(subset='test',
                                 categories=categories, shuffle=True, random_state=42)

count_vect = CountVectorizer()
tfidf_transformer = TfidfTransformer()
clf_mnnb = MultinomialNB()

sk_pipeline = Pipeline([('vect', count_vect),
                        ('tfidf', tfidf_transformer),
                        ('clf', clf_mnnb)
                        ])
sk_model = sk_pipeline.fit(twenty_train.data, twenty_train.target)

predicted2 = list(sk_model.predict(twenty_test.data[:10]))
print ("prediction2:")
pprint.pprint(predicted2)

service_path = "http://localhost:12501"
#service_path = "http://9.30.56.185:12508"
#service_path = "http://9.30.254.136:12501"
#service_path = "http://9.30.56.185:18088"
#service_path = "http://9.30.254.136:12501"

#serviceToken = "Basic YmF0Y2h1c2VyOlpNUmRFMEE3YVlTQU5YbnZMajRLdkdPVjhEQWcwdW5NWEJyOFRPeUhuSmNSYzlTRXA2bTNCZjRUNmpnbjkyZFh4cWJEZ0lQQ1BGTVZYVUdUTmpOUjltUG9uY0lKdU5TNFdDOXE="

serviceToken = "eyJhbGciOiJSUzUxMiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImpnX2lzX3NvX2hhbmRzb21lIiwicm9sZSI6Im1sYWRtIiwidWlkIjoiOTk5IiwiZGlzcGxheV9uYW1lIjoiamdfaXNfc29faGFuZHNvbWUiLCJwcml2aWxlZ2VzIjp7ImNyZWF0ZV9tb2RlbHMiOnRydWUsImRlcGxveV9tb2RlbHMiOnRydWUsInNjb3JlX21vZGVscyI6dHJ1ZX0sImlhdCI6MTUwMjI2NzExNiwiZXhwIjoxNTMxMDY3MTE2fQ.eYOMABTN0jlOLcUacrcwNguKgjuY-3at9lt21B-Xn0tRVmoCB7sJrTu8exeMPfsi6hEgTfoJV_4xlfYPXnUK7MYPL4jACctULP1c-EfyQkXfPcfsfk3FJa2DX_CoqiawLK20ly_u0vz7ne9-zctVO0jMpHhLFokOZY4OZSv5uTkuqz5c8PqlEviKlTGS37I1amxdlNtkJiZ4RBOs83KJK846MlQwkGrNU66p5yASZJ95L72hq_PhdgToM9b6TJXp4RBWER6zbo6FNLp_ytqNkaT1xrqFOEwrQNrZi1YRcFx9hFk03VTcOHZNWIA665k8ImFJxBmHkCO34N-rxvSMFQ"
# Generate mltoken and store it in MLRepositoryClient > MLRepositoryApi > MLApiClient
ml_repository_client = MLRepositoryClient(service_path)
ml_repository_client.authorize_with_token(serviceToken)

props1 = MetaProps({MetaNames.AUTHOR_NAME:"Shuang Yu", MetaNames.AUTHOR_EMAIL:"shuangyu@example.com", MetaNames.MODEL_META_PROJECT_ID:"21e1e07e-ab80-43cb-ba9d-7ca9efe500aa", MetaNames.MODEL_META_MODEL_DATA :"test-model-data", MetaNames.MODEL_META_ORIGIN_TYPE:"notebook", MetaNames.MODEL_META_ORIGIN_ID:"bae68cbf-0371-45aa-a28c-583cf2f3a82c"})
input_artifact = MLRepositoryArtifact(sk_model, name='my_scikit_model_sharon', meta_props=props1)
saved_artifact1 = ml_repository_client.models.save(input_artifact)
dict_meta = saved_artifact1.meta.get()
pprint.pprint(dict_meta)


