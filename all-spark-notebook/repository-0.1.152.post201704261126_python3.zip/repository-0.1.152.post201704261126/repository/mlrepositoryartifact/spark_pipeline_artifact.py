################################################################################
#
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corp. 2017
# US Government Users Restricted Rights - Use, duplication disclosure restricted
# by GSA ADP Schedule Contract with IBM Corp.
#
################################################################################


from .spark_pipeline_reader import SparkPipelineReader
from repository.mlrepository import MetaNames, MetaProps, PipelineArtifact
from repository.util import SparkUtil
from .spark_version import SparkVersion
from .version_helper import VersionHelper
from pyspark.ml import Pipeline


class SparkPipelineArtifact(PipelineArtifact):
    """
    Class of pipeline artifacts created with MLRepositoryCLient.

    :param pyspark.ml.Pipeline ml_pipeline: Pipeline which will be wrapped

    :ivar pyspark.ml.Pipeline ml_pipeline: Pipeline associated with this artifact
    """
    def __init__(self, ml_pipeline, uid=None, name=None, meta_props=MetaProps({})):
        super(SparkPipelineArtifact, self).__init__(uid, name, meta_props)

        if not issubclass(type(ml_pipeline), Pipeline):
            try:
                from mlpipelinepy import MLPipeline
                if not issubclass(type(ml_pipeline), MLPipeline):
                    raise ValueError('Invalid type for ml_pipeline: {}'.format(ml_pipeline.__class__.__name__))
            except:
                raise ValueError('Invalid type for ml_pipeline: {}'.format(ml_pipeline.__class__.__name__))

        self.ml_pipeline = ml_pipeline
        self.meta.merge(
            MetaProps({
                MetaNames.RUNTIME: 'spark-{}'.format(SparkVersion.significant()),
                MetaNames.PIPELINE_TYPE: VersionHelper.pipeline_type(ml_pipeline),
            })
        )

    def pipeline_instance(self):
        return self.ml_pipeline

    def reader(self):
        """
        Returns reader used for getting pipeline content.

        :return: reader for pyspark.ml.Pipeline
        :rtype: SparkPipelineReader
        """
        try:
            return self._reader
        except:
            self._reader = SparkPipelineReader(self.ml_pipeline, 'pipeline')
            return self._reader

    def _copy(self, uid):
        return SparkPipelineArtifact(self.ml_pipeline, uid, self.name, self.meta)
