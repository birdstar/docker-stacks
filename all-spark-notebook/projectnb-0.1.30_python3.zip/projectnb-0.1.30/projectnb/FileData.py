'''
Defines a file data class, which contains information about a project file asset that is relevant to 
the project-notebook integration utility.
'''
class FileData(object):
    def __init__(self, filename, filetype):
        self.filename = filename
        self.filetype = filetype