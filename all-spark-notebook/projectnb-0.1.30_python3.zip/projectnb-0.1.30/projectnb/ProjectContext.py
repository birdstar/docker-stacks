import os

'''
Defines a "project context", which is the data needed to access the data assets 
of a specific DataWorks Project from within a Spark notebook.
'''
class ProjectContext(object):
    ENV_ID_prod = "prod"
    ENV_ID_qa = "qa"
    ENV_ID_YS1_prod = "YS1 prod"
    ENV_ID_dev = "dev"
    ENV_ID_onPrem = "on-prem"
    
    def __init__(self, sc, projectID, accessToken, notebookID, serviceToken, repositoryIp = os.environ.get('ML_VIRTUAL_IP')):
        self.sc = sc
        self.projectID = projectID
        self.accessToken = self.__fixToken(accessToken)
        self.notebookID = notebookID
        self.serviceToken = serviceToken
        self.repositoryIp = self.__fixRepository(repositoryIp)
        self.home = os.environ['HOME']
        self.environment = ProjectContext.ENV_ID_onPrem
        self.debug = False
    '''
    Fixes up the given token value by making sure it starts with "Bearer ".
    '''
    def __fixToken(self, raw_token):
        if raw_token.startswith("Bearer "):
            token = raw_token
        elif raw_token.startswith("bearer "):
            token = "B" + raw_token[1:]
        else:
            token = "Bearer " + raw_token
        return token

    '''
        Fixes up the given repository value.
        '''

    def __fixRepository(self, raw_ip):
        if (raw_ip is None or raw_ip.strip() == ""):
            raw_ip = "PROJECT_SERVICE_URL_var_not_defined"
        return raw_ip
    '''
    Gets and returns the runtime environment: "prod", "qa", "dev" or "YS1 prod".
    '''
    def __getEnvironment(self):
        INVALID_ENV_ID = "invalid_environment_identifier"
        
        RUNTIME_ENV_STOREFRONT = "RUNTIME_ENV_STOREFRONT"
        RUNTIME_ENV_NOTEBOOK = "RUNTIME_ENV_NOTEBOOK"
        ENV_STOREFRONT_BLUEMIX_PROD = "bluemix/prod"
        ENV_STOREFRONT_BLUEMIX_STAGING = "bluemix/staging"
        ENV_STOREFRONT_ONPREM = "on-prem"
        ENV_NOTEBOOK_PROD = "prod"
        ENV_NOTEBOOK_QA = "staging"
        ENV_NOTEBOOK_DEV = "dev"
        ENV_NOTEBOOK_ONPREM = "on-prem"
        
        env_storefront = os.environ[RUNTIME_ENV_STOREFRONT]
        env_notebook = os.environ[RUNTIME_ENV_NOTEBOOK]
        
        envID = INVALID_ENV_ID
        if env_storefront == ENV_STOREFRONT_BLUEMIX_PROD:
            if env_notebook == ENV_NOTEBOOK_PROD:
                envID = ProjectContext.ENV_ID_prod
            elif env_notebook == ENV_NOTEBOOK_QA:
                envID = ProjectContext.ENV_ID_qa
        elif env_storefront == ENV_STOREFRONT_BLUEMIX_STAGING:
            if env_notebook == ENV_NOTEBOOK_PROD:
                envID = ProjectContext.ENV_ID_YS1_prod
            elif env_notebook == ENV_NOTEBOOK_DEV:
                envID = ProjectContext.ENV_ID_dev
        elif env_storefront == ENV_STOREFRONT_ONPREM:
            if env_notebook == ENV_NOTEBOOK_ONPREM:
                envID = ProjectContext.ENV_ID_onPrem
        
        return envID